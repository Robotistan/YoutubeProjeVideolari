# Kütüphaneleri tanımladık.

import time
import board
import digitalio
import usb_hid
from adafruit_hid.keycode import Keycode
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

# Klavyede kullanılan kodların kısaltmalarını tanımladık.

cc = ConsumerControl(usb_hid.devices)

keyboard = Keyboard(usb_hid.devices)

write_text = KeyboardLayoutUS(keyboard)

#Pico'ya takılan butonların portlarını, giriş veya çıkışlarını tanımladık.

btn1_pin = board.GP0
btn1 = digitalio.DigitalInOut(btn1_pin)
btn1.direction = digitalio.Direction.INPUT
btn1.pull = digitalio.Pull.DOWN

btn2_pin = board.GP1
btn2 = digitalio.DigitalInOut(btn2_pin)
btn2.direction = digitalio.Direction.INPUT
btn2.pull = digitalio.Pull.DOWN

btn3_pin = board.GP2
btn3 = digitalio.DigitalInOut(btn3_pin)
btn3.direction = digitalio.Direction.INPUT
btn3.pull = digitalio.Pull.DOWN

btn4_pin = board.GP3
btn4 = digitalio.DigitalInOut(btn4_pin)
btn4.direction = digitalio.Direction.INPUT
btn4.pull = digitalio.Pull.DOWN

btn5_pin = board.GP4
btn5 = digitalio.DigitalInOut(btn5_pin)
btn5.direction = digitalio.Direction.INPUT
btn5.pull = digitalio.Pull.DOWN

while True:
    if btn1.value:
        keyboard.press(Keycode.A)
    if btn1.value==0: 
        keyboard.release(Keycode.A)
   
    if btn2.value:
        keyboard.press(Keycode.S)
    if btn2.value==0:
        keyboard.release(Keycode.S)    
        
    if btn3.value:
        keyboard.press(Keycode.W)
    if btn3.value==0:
        keyboard.release(Keycode.W)    
   
    if btn4.value:
        keyboard.press(Keycode.D)
    if btn4.value==0:
        keyboard.release(Keycode.D)
        
    if btn5.value:
        keyboard.press(Keycode.Space)
    if btn5.value==0:
        keyboard.release(Keycode.Space)
        
time.sleep(0.1)